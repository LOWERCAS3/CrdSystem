<?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';
$sql = "SELECT * FROM fir";
$result = mysqli_query($conn, $sql) or die("Bad query: $sql");
?>
<main>
  <p style="font-size: 30px; text-align: center;">FIRs</p>
  <form  class="searchbox" action="fir.php" method="post">
    <input type="text" name="search">
    <button type="submit" name="viewbutton">Search</button>
  </form>
  <button class="info" type="submit" onclick="location.href='firform.php'">Lodge FIR</button>
  <form class="" action="includes/delete.inc.php" method="post">
  <button class="del" type="submit"name="delete-fir">Delete</button>
<?php
if (!isset($_POST['viewbutton'])) {
  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Fir Id</h1></td>
        <td><h1>Victim</h1></td>
        <td><h1>Fir Date</h1></td>
        <td><h1>Fir Time</h1></td>
        <td><h1>Description</h1></td>
        <td><h1>Region</h1></td>
        <td><h1>Area</h1></td>
        <td><h1>Station</h1></td>
        <td><h1>Suspect</h1></td>
        <td><h1>Delete</h1></td>
        </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>{$row['fir_id']}</td>
          <td>{$row['victim']}</td>
          <td>{$row['fir_date']}</td>
          <td>{$row['fir_time']}</td>
          <td>{$row['dscrptn']}</td>
          <td>{$row['region']}</td>
          <td>{$row['area']}</td>
          <td>{$row['station']}</td>
          <td>{$row['suspect']}</td>
          <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['fir_id']}' /></td>
          <td><a href='firedit.php?id={$row['fir_id']}'>Edit</a></td>
          </tr>";
    }
  echo "</table>";
}
else {
  $search = $_POST['search'];
  $sql = "SELECT * FROM fir WHERE fir_id LIKE '%$search%' OR victim LIKE '%$search%' OR fir_date LIKE '%$search%' OR dscrptn LIKE '%$search%' OR region LIKE '%$search%' OR  area LIKE '%$search%' OR suspect LIKE '%$search%'OR station LIKE '%$search%';";
  $result = mysqli_query($conn,$sql);
  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Fir Id</h1></td>
        <td><h1>Victim</h1></td>
        <td><h1>Fir Date</h1></td>
        <td><h1>Fir Time</h1></td>
        <td><h1>Description</h1></td>
        <td><h1>Region</h1></td>
        <td><h1>Area</h1></td>
        <td><h1>Station</h1></td>
        <td><h1>Suspect</h1></td>
        <td><h1>Delete</h1></td>
        </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td> <a href='firsdetails.php?id={$row['fir_id']}'>{$row['fir_id']}</a></td>
          <td>{$row['victim']}</td>
          <td>{$row['fir_date']}</td>
          <td>{$row['fir_time']}</td>
          <td>{$row['dscrptn']}</td>
          <td>{$row['region']}</td>
          <td>{$row['area']}</td>
          <td>{$row['suspect']}</td>
          <td>{$row['suspect']}</td>
          <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['fir_id']}' /></td>
          <td><a href='firedit.php?id={$row['fir_id']}'>Edit</a></td>
          </tr>";
    }
  echo "</table>";
}
 ?>
</main>
<?php

if (!empty($_GET)) {
if ($_GET['status']== "notadmin") {
echo "<script>
  alert('You do not have necessary privileges.');
</script>";
}
elseif ($_GET['status']== "updated") {
  echo "<script>
    alert('Database updated.');
  </script>";
}
}
 ?>
