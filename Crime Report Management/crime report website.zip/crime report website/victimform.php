<?php
  include_once 'header.php';
?>
<main>
  <form class="" action="includes/victim.inc.php" method="post" enctype="multipart/form-data">
    <h1 class="formtitle">VICTIM DETAILS</h1>
    <hr>
    <pre>
                    Upload Image :         <input style="color:white;" type="file" required name="image"><br>
                    Case ID :                        <input type="text" name="case_id" value=""><br>
                    Name :                           <input type="text" name="vname" value=""><br>
                    Statement :                  <textarea name="statement" rows="2" cols="30"></textarea><br>
                    Age :                                <input type="text" name="age" value=""><br>
                    Gender:                         Male : <input type="radio" name="gender" value="Male"> Female : <input type="radio" name="gender" value="Female"><br>
                    Address:                        <textarea name="addr" rows="2" cols="30"></textarea><br>
  </pre>
  <button class="prisonerformbutton" type="submit" name="victim_submit">Submit</button>
</form>
</main>
<?php
if(!empty($_GET)){
if($_GET['error']=='format'){
echo '<script> alert("Unsupported image format!"); </script>';
}
}
?>
