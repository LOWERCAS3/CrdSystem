<?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';
$firId = $_GET['id'];
$sql = "SELECT * FROM fir WHERE  fir_id = '$firId';";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$firId = $row['fir_id'];
$name = $row['victim'];
$region = $row['region'];
$firdate = $row['fir_date'];
$firtime = $row['fir_time'];
$area = $row['area'];
$suspects = $row['suspect'];
$station = $row['station'];
$description = $row['dscrptn'];

?>
<main>
  <script>
    function populate(s1,s2){
      var s1 = document.getElementById(s1);
      var s2 = document.getElementById(s2);
      s2.innerHTML = "";
      s2.value = "Select";
      if(s1.value == "Bastar"){
        var optionArray = ["|Select","Bastar|Bastar","Bijapur|Bijapur","Dantewada|Dantewada","Kondagaon|Kondagaon","Narayanpur|Narayanpur","Kanker|Kanker"];
      } else if(s1.value == "Bilaspur"){
        var optionArray = ["|Select","Bilaspur|Bilaspur"," Mungeli|Mungeli ","Korba|Korba","Janjgir Champa|Janjgir Champa","Raigarh|Raigarh"];
      } else if(s1.value == "Durg"){
        var optionArray = ["|Select","Kawardha|Kawardha","Rajnandgaon|Rajnandgaon","Balod|Balod","Durg|Durg","Bemetara|Bemetara"];
      } else if(s1.value == "Raipur"){
        var optionArray = ["|Select","Dhamtari|Dhamtari","Gariyaband|Gariyaband","Raipur|Raipur","Baloda Bazar|Baloda Bazar","Mahasamund|Mahasamund"];
      } else if(s1.value == "Surguja"){
        var optionArray = ["|Select","Koriya|Koriya","Surajpur|Surajpur","Balrampur Ramanujgang|Balrampur Ramanujgang"," Jashpur|Jashpur "];
      }

      for(var option in optionArray){
        var pair = optionArray[option].split("|");
        var newOption = document.createElement("option");
        newOption.value = pair[0];
        newOption.innerHTML = pair[1];
        s2.options.add(newOption);
      }
    }
  </script>
  <h1 class="formtitle">LODGE FIR</h1>
  <hr>
  <form class="" action="includes/update.inc.php?id=<?php echo $firId;?>" method="post">
    <pre>

                FIR Id :                      <?php echo $firId;?><br>
                Name  :                   <input type="text" required name="Victim" placeholder="Full Name" value="<?php echo $name;?>"><br>
                FIR Date  :               <input type="date" required name="FIR_Date"value="<?php echo $firdate;?>"><br>
                FIR Time  :               <input type="time" required name="Fir_Time"value="<?php echo $firtime;?>" ><br>
                Region  :                 <select style="color: black;" id="slct1" required name="slct1" onchange="populate(this.id,'slct2')">
                                                <option value="<?php echo $region;?>"><?php echo $region;?></option>
                                                <option value="Bastar">Bastar</option>
                                                <option value="Bilaspur">Bilaspur</option>
                                                <option value="Drug">Drug</option>
                                                <option value="Raipur">Raipur</option>
                                                <option value="Surguja">Surguja</option></select><br><br>
                Area    :                    <select style="color: black;" id="slct2" required name="slct2"></select></select><br>
                Station Name  :    <input type="text" required name="station"  placeholder="Add station name"value="<?php echo $station;?>"><br>
                Suspects  :             <input type="text" name="suspect" placeholder="Add names here"value="<?php echo $suspects;?>"><br>
                Description :         <textarea  type="text" rows="3" cols="90" required name="dscrptn" placeholder="Fill here.."  >a<?php echo $description;?></textarea><br><br>
    </pre>
      <button  class="prisonerformbutton" type="submit" name="update-fir-submit">Submit</button>
    </form>
  </main>
</main>
