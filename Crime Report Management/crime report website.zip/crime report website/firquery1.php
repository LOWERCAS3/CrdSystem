<?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';
 ?>
 <main>
<pre style="text-align: center;">
   <form class="" action="" method="POST">
     Enter dates to get analysis :   date-from :  <input required type="date" name="datefrom" value="">    date-to : <input type="date" name="dateto" value="">  <button type="submit" name="querybutton">submit</button>
  </form>
</pre>
<?php
 if (isset($_POST['querybutton'])) {
  $datefrom = $_POST['datefrom'];
  $dateto = $_POST['dateto'];

  $sql1 = "SELECT*FROM fir";
  $result1 = mysqli_query($conn,$sql1);
  $numrows1 = mysqli_num_rows($result1);
  // echo $numrows1;

  $sql2 = "SET @totalrows= '$numrows1';";
  mysqli_query($conn,$sql2);

  $sql = "SELECT * FROM fir WHERE fir_date BETWEEN '$datefrom' AND '$dateto'; ";
  $result = mysqli_query($conn,$sql);
  $numrows = mysqli_num_rows($result);
if ($numrows!='0') {

  $sql3 ="SET @searchedrows= '$numrows';";
  mysqli_query($conn,$sql3);

  $sql4 = "call percent(@totalrows,@searchedrows, @percentage);";
  mysqli_query($conn,$sql4);

  $sql5 = "SELECT @percentage;";
  $rslt =   mysqli_query($conn,$sql5);
  // echo $rslt ;

  while ($row1 = $rslt->fetch_assoc()) {?>
    <pre style="text-align: center;"><?php  echo  $row1['@percentage']."% of the total FIR had been lodged in between ".$datefrom." and ".$dateto?></pre>

  <?php
 }


  // echo $numrows;
  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Fir Id</h1></td>
        <td><h1>Victim</h1></td>
        <td><h1>Fir Date</h1></td>
        <td><h1>Fir Time</h1></td>
        <td><h1>Description</h1></td>
        <td><h1>Region</h1></td>
        <td><h1>Area</h1></td>
        <td><h1>Suspect</h1></td>
        </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td> <a href='firsdetails.php?id={$row['fir_id']}'>{$row['fir_id']}</a></td>
          <td>{$row['victim']}</td>
          <td>{$row['fir_date']}</td>
          <td>{$row['fir_time']}</td>
          <td>{$row['dscrptn']}</td>
          <td>{$row['region']}</td>
          <td>{$row['area']}</td>
          <td>{$row['suspect']}</td>
          </tr>";
    }
  echo "</table>";
}
else {?>
<pre style="text-align: center;">
<?php   echo "No data found!"; ?>
</pre>
  <?php
}
}

?>
</main>
