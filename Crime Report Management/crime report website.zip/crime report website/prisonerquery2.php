<?php
include_once 'includes/dbh.inc.php';
include_once 'header.php';
 ?>
 <main>
<pre style="text-align: center;">
<form class="" action="" method="post">
     Select the type of crime to get analysis:  <select   style="color: black;" name="crime">
                         <option value="">Select</option>
                         <option value="Antisocial&nbsp;behaviour">Antisocial behaviour</option>
                         <option value="Arson">Arson</option>
                         <option value="Burglary">Burglary</option>
                       <option value="Childhood abuse">Childhood abuse</option>
                       <option value="Crime abroad">Crime abroad</option>
                       <option value="Cyber crime">Cyber crime</option>
                       <option value="Domestic abuse">Domestic abuse</option>
                       <option value="Fraud">Fraud</option>
                       <option value="Hate crime">Hate crime</option>
                       <option value="Murder">Murder</option>
                       <option value="Rape and sexual assault">Rape and sexual assault</option>
                       <option value="Revenge porn">Revenge porn</option>
                       <option value="Robbery">Robbery</option>
                       <option value="Sexual harassment">Sexual harassment</option>
                       <option value="Stalking and harassment">Stalking and harassment</option>
                       <option value="Terrorism">Terrorism</option>
                       <option value="Violent crime">Violent crime</option>
                       </select><button type="submit" name="querybutton">submit</button>
</form>
</pre>
<?php
 if (isset($_POST['querybutton'])) {
   $pcrime = $_POST['crime'];
  $sql1 = "SELECT*FROM prisoner";
  $result1 = mysqli_query($conn,$sql1);
  $numrows1 = mysqli_num_rows($result1);
  // echo $numrows1;

  $sql2 = "SET @totalrows= '$numrows1';";
  mysqli_query($conn,$sql2);

  $sql = "SELECT * FROM prisoner WHERE crime = '$pcrime' ;";
  $result = mysqli_query($conn,$sql);
  $numrows = mysqli_num_rows($result);
  // echo $numrows;

  $sql3 ="SET @searchedrows= '$numrows';";
  mysqli_query($conn,$sql3);

  $sql4 = "call percent(@totalrows,@searchedrows, @percentage);";
  mysqli_query($conn,$sql4);

  $sql5 = "SELECT @percentage;";
  $rslt =   mysqli_query($conn,$sql5);
  // echo $rslt ;

  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Defendants Id</h1></td>
            <td><h1>Name</h1></td>
            <td><h1>Address</h1></td>
            <td><h1>Age</h1></td>
            <td><h1>Gender</h1></td>
            <td><h1>Arrest Date</h1></td>
            <td><h1>Arrest Time</h1></td>
            <td><h1>Crime</h1></td>
            <td><h1>Status</h1></td>
            <td><h1>Delete</h1></td>
            </tr>";

while ($row = mysqli_fetch_assoc($result)) {
echo "<tr><td> <a href='prisonersdetails.php?id={$row['pri_id']}'>{$row['pri_id']}</a></td>
          <td>{$row['name']}</td>
          <td>{$row['address']}</td>
          <td>{$row['age']}</td>
          <td>{$row['gender']}</td>
          <td>{$row['arrest_date']}</td>
          <td>{$row['arrest_time']}</td>
          <td>{$row['crime']}</td>
          <td>{$row['sttus']}</td>
          <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['pri_id']}' /></td>
          <td><a href='prisoneredit.php?id={$row['pri_id']}'>Edit</a></td>
          </tr>";
        }
echo "</table>";

while ($row1 = $rslt->fetch_assoc()) {?>
  <pre style="text-align: center;"><?php echo  $row1['@percentage']."% of defendant are accused of commiting ".$pcrime.'.';
 ?></pre>
<?php
}
}
?>
</main>
