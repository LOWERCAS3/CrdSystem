<?php
include_once 'header.php';
 ?>
 <main>
   <u><pre style="font-size: 40px; text-align: center;">

Select query related area</pre>
     </u>
   <pre style=" text-align: center;" >


   <form class="" action="" method="post">
   <button style="font-size: 30px;" class="queryclass" type="submit" onclick="location.href=''" name="Prisoner">Defendant</button>   <button style="font-size: 30px;" class="queryclass" type="submit" onclick="location.href='firquery.php'" name="FIRs">FIRs</button>   <button style="font-size: 30px;" class="queryclass" type="submit" onclick="location.href=''" name="Victims">Victims</button>
  </pre>
   <!-- <button class="queryclass" type="submit" onclick="location.href='casesquery.php'" name="Cases">Cases</button> -->
 </form>
 <hr style=" margin-left:570px; width: 800px;">
 <?php if(isset($_POST['Prisoner'])) {?>
   <pre style=" text-align: center;">
      <button type="submit" onclick="location.href='prisonerquery1.php'" name="prisoner">STATUS OF DEFENDENT</button>
      <button type="button" onclick="location.href='prisonerquery2.php'" name="crime">CRIME</button>
      <button type="button" onclick="location.href='prisonerquery3.php'" name="time">ARREST(DATE)</button>
      <button type="button" onclick="location.href='prisonerquery4.php'" name="crime">ARREST(TIME)</button>
      <button type="button" onclick="location.href='prisonerquery5.php'" name="crime">AGE</button>
      </pre>
      <?php
}
?>
    <?php if(isset($_POST['FIRs'])) { ?>
         <pre style=" text-align: center;">
          <button type="submit" onclick="location.href='firquery1.php'" name="FIRs">FIR RATE(DATE)</button>
         <button type="submit" onclick="location.href='firquery2.php'" name="FIRs">FIR RATE(TIME)</button>
         <button type="submit" onclick="location.href='firquery3.php'" name="FIRs">REGION</button>
</pre>
     <?php
     }
     ?>
     <?php if(isset($_POST['Victims'])) {?>
          <pre style=" text-align: center;">
          <button type="submit" onclick="location.href='victimquery1.php'" name="prisoner">CASE</button>
          <button type="button" onclick="location.href='victimquery2.php'" name="crime">AGE</button>
        </pre>
    <?php
    }
    ?>

   </main>



   <!-- <?php if(isset($_POST['Cases'])) {?> -->
     <!-- select your field of analysis
        <button type="submit" onclick="location.href='casesquery1.php'" name="prisoner">CASE</button>
        <button type="button" onclick="location.href='casesquery2.php'" name="crime">STATUS</button> -->
  <!-- <?php
  }
  ?>-->
