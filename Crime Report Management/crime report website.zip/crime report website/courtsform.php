<?php
include_once 'header.php';
 ?>
<main>
  <h1 class="formtitle">NEW COURT</h1>
<hr>
<pre>

  <form class="" action="includes/courts.inc.php" method="post">
                Court name  :       <input type="text" name="crt_name"><br>
                Address :                <input type="text" name="crt_addr"><br>
                Type  :                      <select style="color : black;"class="" name="crt_type">
                                                <option value="">Select</option>
                                                <option value="HighCourt">High Court</option>
                                                <option value="SupremeCourt">Supreme Court</option>
                                                <option value="DistrictCourt">District Court</option>
                                              </select>
    <button  class="prisonerformbutton" type="submit" name="courts_submit">Submit</button>
  </form>
</pre>
</main>
