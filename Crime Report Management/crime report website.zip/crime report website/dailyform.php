<?php include_once 'header.php';?>
<main>
    <form class="" action="includes/daily.inc.php" method="post" enctype="multipart/form-data">
        <h1 class="formtitle">ADD A REPORT</h1>
      <hr>
      <pre>
            Name:                     <input required type="text" name="name" value=""><br>
            Age:                         <input required  type="text" name="dage" value=""><br>
            Gender:                  Male: <input required type="radio" name="dgender" value="Male">       Female: <input type="radio" name="dgender" value="Female"> <br>
            Date:                       <input required type="date" style="color: black;" name="ddate" placeholder="YYYY-MM-DD"><br>
            Reason:                  <input required type="text" name="dreason" value=""><br>

            Description:           <textarea style=" color: black;"name="ddescription" rows="3" cols="90" placeholder="Fill here.." ></textarea><br>
            Address:                 <textarea required name="daddress" rows="3" cols="90"></textarea><br>
        </pre>
        <button class="dailyformbutton" type="submit" name="daily_submit">Submit</button>
    </form>
</main>
