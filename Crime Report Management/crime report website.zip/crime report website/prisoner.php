<?php
  include_once 'header.php';
  include_once 'includes/dbh.inc.php';
  $sql = "SELECT * FROM prisoner";
  $result = mysqli_query($conn, $sql) or die("Bad query: $sql");
?>
<main>
  <p style="font-size: 30px; text-align: center;">Defendents</p>
  <form  class="searchbox" action="prisoner.php" method="post">
    <input type="text" name="search">
    <button type="submit" name="viewbutton">Search</button>
  </form>
  <button class="info" type="submit" onclick="location.href='prisonerform.php'">Add Defendent info</button>
  <form class="" action="includes/delete.inc.php" method="post">
  <button class="del" type="submit"name="delete-pri">Delete</button>
  <?php

    if (!isset($_POST['viewbutton'])) {
      echo "<table class='showtable' border='1'>";
      echo " <tr><td><h1>Defendent Id</h1></td>
                <td><h1>Name</h1></td>
                <td><h1>Age</h1></td>
                <td><h1>Gender</h1></td>
                <td><h1>Arrest Date</h1></td>
                <td><h1>Crime</h1></td>
                <td><h1>Status</h1></td>
                <td><h1>Type</h1></td>
                <td><h1>Delete</h1></td>
                </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td> <a href='prisonersdetails.php?id={$row['pri_id']}'>{$row['pri_id']}</a></td>
              <td>{$row['name']}</td>
              <td>{$row['age']}</td>
              <td>{$row['gender']}</td>
              <td>{$row['arrest_date']}</td>
              <td>{$row['crime']}</td>
              <td>{$row['sttus']}</td>
              <td>{$row['agegrp']}</td>
              <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['pri_id']}' /></td>
              <td><a href='prisoneredit.php?id={$row['pri_id']}'>Edit</a></td>
              </tr>";
            }
    echo "</table>";
    }
    else {
      $search = $_POST['search'];
      $sql = "SELECT * FROM prisoner WHERE pri_id LIKE '%$search%' OR name LIKE '%$search%' ;";
      $result = mysqli_query($conn,$sql);
      echo "<table class='showtable'>";
      echo " <tr><td><h1>Defendent Id</h1></td>
                <td><h1>Name</h1></td>
                <td><h1>Age</h1></td>
                <td><h1>Gender</h1></td>
                <td><h1>Arrest Date</h1></td>
                <td><h1>Crime</h1></td>
                <td><h1>Status</h1></td>
                <td><h1>Type</h1></td>
                <td><h1>Delete</h1></td>
                  </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
      echo "<tr><td> <a href='prisonersdetails.php?id={$row['pri_id']}'>{$row['pri_id']}</a></td>
                <td>{$row['name']}</td>
                <td>{$row['age']}</td>
                <td>{$row['gender']}</td>
                <td>{$row['arrest_date']}</td>
                <td>{$row['crime']}</td>
                <td>{$row['sttus']}</td>
                <td>{$row['agegrp']}</td>
                <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['pri_id']}' /></td>
                <td><a href='prisoneredit.php?id={$row['pri_id']}'>Edit</a></td>
                </tr>";
    }
    echo "</table>";
    }
  ?>
</form>
</main>
<?php

if (!empty($_GET)) {
if ($_GET['status']== "notadmin") {
echo "<script>
  alert('You do not have necessary privileges.');
</script>";
}
elseif ($_GET['status']== "updated") {
  echo "<script>
    alert('Database updated.');
  </script>";
}
}
 ?>
