<?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';
 ?>
 <main>
<pre style="text-align: center;">
   <form class="" action="" method="POST">
     Enter Age group to get analysis :   <select style="color:black;" class="" name="agegrp">
       <option value="">Select</option>
       <option value="Adult">Adult</option>
       <option value="Minor">Minor</option>
     </select> <button type="submit" name="querybutton">submit</button>
  </form>
</pre>
<?php
 if (isset($_POST['querybutton'])) {
  $agegrp = $_POST['agegrp'];

  $sql1 = "SELECT*FROM victim";
  $result1 = mysqli_query($conn,$sql1);
  $numrows1 = mysqli_num_rows($result1);
  // echo $numrows1;

  $sql2 = "SET @totalrows= '$numrows1';";
  mysqli_query($conn,$sql2);

  $sql = "SELECT * FROM victim WHERE agegrp = '$agegrp' ; ";
  $result = mysqli_query($conn,$sql);
  $numrows = mysqli_num_rows($result);
if ($numrows!='0') {


  $sql3 ="SET @searchedrows= '$numrows';";
  mysqli_query($conn,$sql3);

  $sql4 = "call percent(@totalrows,@searchedrows, @percentage);";
  mysqli_query($conn,$sql4);

  $sql5 = "SELECT @percentage;";
  $rslt =   mysqli_query($conn,$sql5);
  // echo $rslt ;
  while ($row1 = $rslt->fetch_assoc()) {?>
    <pre style="text-align: center;">
      <?php  echo  $row1['@percentage']."% of the victims are ".$agegrp.".";?>
  </pre>
  <?php
  }
  // echo $numrows;

  echo "<table class ='showtable'>";
  echo " <tr> <td><h1>Victim Id</h1></td>
              <td><h1>Case Id</h1></td>
              <td><h1>Name</h1></td>
              <td><h1>Age</h1></td>
              <td><h1>Gender</h1></td>
              <td><h1>Type</h1></td>
              </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
      echo "
              <tr><td> <a href='victimdetails.php?id={$row['vict_id']}'>{$row['vict_id']}</a></td>
              <td>{$row['case_id']}</td>
              <td>{$row['vict_name']}</td>
              <td>{$row['vict_age']}</td>
              <td>{$row['vict_gender']}</td>
              <td>{$row['agegrp']}</td>
              </tr>
            ";
    }
  echo "</table>";
  }
  else {?>
<pre style="text-align: center;">
  <?php   echo "No victim exists!"; ?>
</pre>
    <?php
  }
}

?>
</main>
