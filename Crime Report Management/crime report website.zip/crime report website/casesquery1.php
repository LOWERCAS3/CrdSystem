<?php
include_once 'includes/dbh.inc.php';
include_once 'header.php';
 ?>
 <main>
<form class="" action="" method="post">
   Enter Case Id <input type="text" name="" value="">
   Choose Status <select  style="color: black;" name="pstatus">
    <option value="">Select</option>
    <option value="arrested">Arrested</option>
    <option value="OnBail">On Bail</option>
    <option value="sentenced">Sentenced</option>      
    </select>
    <button type="submit" name="querybutton">submit</button>
</form>
<?php
 if (isset($_POST['querybutton'])) {
 $caseid = $_POST['caseid'];
 $pstatus = $_POST['pstatus'];
  $sql1 = "SELECT * FROM cases";
  $result1 = mysqli_query($conn,$sql1);
  $numrows1 = mysqli_num_rows($result1);
  // echo $numrows1;

  $sql2 = "SET @totalrows= '$numrows1';";
  mysqli_query($conn,$sql2);

  $sql = "SELECT pri_id FROM cases c , prisoner p WHERE case_id='$caseid' AND c.pri_id = p.pri_id AND sttus = '$pstatus' ;";
  $result = mysqli_query($conn,$sql);
  $numrows = mysqli_num_rows($result);
  // echo $numrows;

  $sql3 ="SET @searchedrows= '$numrows';";
  mysqli_query($conn,$sql3);

  $sql4 = "call percent(@totalrows,@searchedrows, @percentage);";
  mysqli_query($conn,$sql4);

  $sql5 = "SELECT @percentage;";
  $rslt =   mysqli_query($conn,$sql5);
  // echo $rslt ;

  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Prisoner Id</h1></td>
            <td><h1>Name</h1></td>
            <td><h1>Address</h1></td>
            <td><h1>Age</h1></td>
            <td><h1>Gender</h1></td>
            <td><h1>Arrest Date</h1></td>
            <td><h1>Arrest Time</h1></td>
            <td><h1>Crime</h1></td>
            <td><h1>Status</h1></td>
            </tr>";

while ($row = mysqli_fetch_assoc($result)) {
echo "<tr><td> <a href='prisonersdetails.php?id={$row['pri_id']}'>{$row['pri_id']}</a></td>
          <td>{$row['name']}</td>
          <td>{$row['address']}</td>
          <td>{$row['age']}</td>
          <td>{$row['gender']}</td>
          <td>{$row['arrest_date']}</td>
          <td>{$row['arrest_time']}</td>
          <td>{$row['crime']}</td>
          <td>{$row['sttus']}</td>
          </tr>";
        }
echo "</table>";

while ($row1 = $rslt->fetch_assoc()) {
echo  $row1['@percentage']."% of prisoner are ".$pstatus;
}
}
?>
</main>
