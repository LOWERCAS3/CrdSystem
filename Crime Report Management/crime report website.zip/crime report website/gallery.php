

<link rel="stylesheet" href="style.css">
 <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
<main class="headerPHP">
  <div class="headerlogo">
    <ul>
    <a href="index.php"><img  class="nav-header-logo" src="img/icon.png" alt="logo" ></a>

    <li><a href="index.php">Home</a></li>
    <li><a href="">Gallery</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="contact.php">Contact</a></li>
          </ul>
    <?php
      if (isset($_SESSION['userId'])) {
        echo   '  <form class="" action="includes/logout.inc.php" method="post">
                  <button type="submit" name="logout-submit">Logout</button>
                  </form>';
      }
    ?>
  </div>
  <hr style="margin-top: 65px;">
  <div id="container">
    <div id="sliderbox">
        	<img src="policegallery/new1.jpg" alt="" />
        	<img src="policegallery/2.jpg" alt="" />
        	<img src="policegallery/3.jpg" alt="" />
        	<img src="policegallery/4.jpg" alt="" />
        </div>
  </div>

</main>
