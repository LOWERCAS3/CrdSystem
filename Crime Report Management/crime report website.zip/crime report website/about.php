

<link rel="stylesheet" href="style.css">
 <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
<main class="headerPHP">
  <div class="headerlogo">
    <ul>
    <a href="index.php"><img  class="nav-header-logo" src="img/icon.png" alt="logo" ></a>

    <li><a href="index.php">Home</a></li>
    <li><a href="gallery.php">Gallery</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="contact.php">Contact</a></li>
          </ul>
    <?php
      if (isset($_SESSION['userId'])) {
        echo   '  <form class="" action="includes/logout.inc.php" method="post">
                  <button type="submit" name="logout-submit">Logout</button>
                  </form>';
      }
    ?>
  </div>
  <hr style="margin-top: 65px;">
<main>

  <p style="margin-top: 150px;">
    The district police administration is headed by a Superintendent of Police. A group of districts comprise a range, led by an Inspector General of Police. Police administration in Bengaluru is headed by a commissioner of police with the rank of Additional DGP. Mysuru, Mangaluru and Hubballi-Dharwad city are headed by an Inspector General of Police(IGP) while Belagavi is headed by a Deputy Inspector General of Police (DIG).</p><br>

  <p>The Director General and Inspector General of Police (DG&IGP) is the head of the state's police department, and under him are Additional Directors Generals of Police. Each Additional Director General of Police is in charge of a particular function: law and order, crime and technical services, administration, intelligence, the Karnataka State Reserve Police, recruitment and training.</p><br>

  <p>There are five Commissionarates. The Commissioner of Police, Bangalore City has the rank of Additional Director General of Police, and the commissioners in Hubballi-Dharwad, Mysuru and Mangaluru have the rank of Inspector General of Police while the Belagavi commissioner has the rank of Deputy Inspector General of Police. Six Inspectors General of Police are in charge of ranges, with several Inspectors General of Police in charge of specific functions. Each Range comprises three to six districts, and each district is headed by a Superintendent of Police.</p>
</main>
