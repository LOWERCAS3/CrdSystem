  <?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';

$sql = "SELECT * FROM victim  ";
$result = mysqli_query($conn, $sql) or die("Bad query: $sql");
 ?>
<main>
  <p style="font-size: 30px; text-align: center;">Victims</p>
  <form  class="searchbox" action="victim.php" method="post">
    <input type="text" name="search">
    <button type="submit" name="viewbutton">Search</button>
  </form>
  <button class="info" type="submit" onclick="location.href='victimform.php'">Add Victims Info</button>
  <form class="" action="includes/delete.inc.php" method="post">
  <button class="del" type="submit"name="delete-victim">Delete</button>
<?php
echo "<table class ='showtable'border='1'>";
echo " <tr> <td><h1>Victim Id</h1></td>
            <td><h1>Case Id</h1></td>
            <td><h1>Name</h1></td>
            <td><h1>Age</h1></td>
            <td><h1>Gender</h1></td>
            <td><h1>Type</h1></td>
            <td><h1>Delete</h1><td>
        </tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "
            <tr><td> <a href='victimdetails.php?id={$row['vict_id']}'>{$row['vict_id']}</a></td>
            <td>{$row['case_id']}</td>
            <td>{$row['vict_name']}</td>
            <td>{$row['vict_age']}</td>
            <td>{$row['vict_gender']}</td>
            <td>{$row['agegrp']}</td>
            <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['vict_id']}' /></td>
            <td><a href='victimedit.php?id={$row['vict_id']}'>Edit</a></td>

            </tr>
          ";
  }
echo "</table>";
 ?>
 </form>
</main>
<?php

if (!empty($_GET)) {
if ($_GET['status']== "notadmin") {
echo "<script>
  alert('You do not have necessary privileges.');
</script>";
}
elseif ($_GET['status']== "updated") {
  echo "<script>
    alert('Database updated.');
  </script>";
}
else{

}
}
 ?>
