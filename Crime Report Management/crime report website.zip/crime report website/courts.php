<?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';

$sql = "SELECT * FROM court";
$result = mysqli_query($conn, $sql) or die("Bad query: $sql");
?>
<main>
  <p style="font-size: 30px; text-align: center;">Courts</p>
  <form  class="searchbox" action="courts.php" method="post">
    <input type="text" name="search">
    <button type="submit" name="viewbutton">Search</button>
  </form>
  <button class="info" type="submit" onclick="location.href='courtsform.php'">Add new courts</button>
  <form class="" action="includes/delete.inc.php" method="post">
  <button class="del" type="submit"name="delete-courts">Delete</button>
<?php
    if (!isset($_POST['viewbutton'])) {
      echo "<table class='showtable' border='1'>";
      echo " <tr><td><h1>Court Id</h1></td>
            <td><h1>Court Name</h1></td>
            <td><h1>Address</h1></td>
            <td><h1>Court Type</h1></td>
            <td><h1>Delete</h1></td>
            </tr>";

      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td>{$row['crt_id']} </td>
              <td>{$row['crt_name']}</td>
              <td>{$row['crt_place']}</td>
              <td>{$row['crt_type']}</td>
              <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['crt_id']}' /></td>
              </tr>";
        }

      echo "</table>";
    }
    else {
      $search = $_POST['search'];
      $sql = "SELECT * FROM court WHERE crt_id LIKE '%$search%' OR crt_name LIKE '%$search%' OR crt_place LIKE '%$search%' OR crt_type LIKE '%$search%';";
      $result = mysqli_query($conn,$sql);
      echo "<table class='showtable' border='1'>";
      echo " <tr><td><h1>Court Id</h1></td>
            <td><h1>Court Name</h1></td>
            <td><h1>Address</h1></td>
            <td><h1>Court Type</h1></td>
            <td><h1>Delete</h1></td>

            </tr>";

      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td>{$row['crt_id']} </td>
              <td>{$row['crt_name']}</td>
              <td>{$row['crt_place']}</td>
              <td>{$row['crt_type']}</td>
              <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['crt_id']}' /></td>
              </tr>";
    }
    echo "</table>";
    }
 ?>
 </form>
</main>
<?php

if (!empty($_GET)) {
if ($_GET['status']== "notadmin") {
echo "<script>
  alert('You do not have necessary privileges.');
</script>";
}
elseif ($_GET['status']== "updated") {
  echo "<script>
    alert('Database updated.');
  </script>";
}
}
 ?>
