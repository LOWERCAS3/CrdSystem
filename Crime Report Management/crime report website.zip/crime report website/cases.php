<?php
  include_once 'header.php';
  include_once 'includes/dbh.inc.php';

  $sql = "SELECT * FROM cases";
  $result = mysqli_query($conn, $sql) or die("Bad query: $sql");
?>
<main>
  <p style="font-size: 30px; text-align: center;">Cases</p>
  <form  class="searchbox" action="cases.php" method="post">
    <input type="text" name="search">
    <button type="submit" name="viewbutton">Search</button>
  </form>
  <button class="info" type="submit" onclick="location.href='casesform.php'">File Case</button>
  <form class="" action="includes/delete.inc.php" method="post">
    <button class="del" type="submit"name="delete-case">Delete</button>
  <?php

  if (!isset($_POST['viewbutton'])) {
  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Case Id</h1></td>
  <td><h1>Defendent Id</h1></td>
  <td><h1>Court Id</h1></td>
  <td><h1>Hearing Date</h1></td>
  <td><h1>Arrests</h1></td>
  <td><h1>FIR Id</h1></td>
  <td><h1>Delete</h1></td>
  </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
  echo "<tr><td>{$row['case_id']}</td>
    <td>{$row['pri_id']}</td>
    <td>{$row['crt_id']}</td>
    <td>{$row['hearing_date']}</td>
    <td>{$row['arrests']}</td>
    <td>{$row['fir_id']}</td>
    <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['case_id']}' /></td>
    </tr>";
  }
  echo "</table>";
}
else {
  $search = $_POST['search'];
  $sql = "SELECT * FROM cases WHERE case_id LIKE '%$search%' OR pri_id LIKE '%$search%' OR crt_id LIKE '%$search%' OR hearing_date LIKE '%$search%' OR arrests LIKE '%$search%' OR  fir_id LIKE '%$search%';";
  $result = mysqli_query($conn,$sql);
  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Case Id</h1></td>
  <td><h1>Defendent Id</h1></td>
  <td><h1>Court Id</h1></td>
  <td><h1>Hearing Date</h1></td>
  <td><h1>Arrests</h1></td>
  <td><h1>FIR Id</h1></td>
  <td><h1>Delete</h1></td>
  </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
  echo "<tr><td>{$row['case_id']}</td>
    <td>{$row['pri_id']}</td>
    <td>{$row['crt_id']}</td>
    <td>{$row['hearing_date']}</td>
    <td>{$row['arrests']}</td>
    <td>{$row['fir_id']}</td>
    <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['case_id']}' /></td>
    </tr>";
  }
  echo "</table>";
}
  ?>
</form>
</main>
<?php

if (!empty($_GET)) {
if ($_GET['status']== "notadmin") {
echo "<script>
  alert('You do not have necessary privileges.');
</script>";
}
elseif ($_GET['status']== "updated") {
  echo "<script>
    alert('Database updated.');
  </script>";
}
}
 ?>
