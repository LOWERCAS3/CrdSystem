<?php

if(isset($_POST['daily_submit']))
{
include_once 'dbh.inc.php';
$dname = $_POST['name'];
$dage = $_POST['dage'];
$dgender = $_POST['dgender'];
$ddate = $_POST['ddate'];
$dreason = $_POST['dreason'];
$ddescription = $_POST['ddescription'];
$daddress = $_POST['daddress'];

$sql = "INSERT INTO dailyreport (dname, dage, dgender, ddate, dreason, ddescription, daddress) VALUES ('$dname', '$dage', '$dgender', '$ddate', '$dreason', '$ddescription', '$daddress');";
mysqli_query($conn, $sql);
header("Location: ../dailyreport.php?status=entered");
exit();
}
