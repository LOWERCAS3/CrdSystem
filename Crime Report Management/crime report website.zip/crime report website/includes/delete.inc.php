<?php
session_start();

if (isset($_POST['delete-pri'])) {
include_once 'dbh.inc.php';
if (  $_SESSION['admin'] == 1) {
 $delete_id =  $_POST['checkbox'];
 $id = count($delete_id);
 if (count($id) > 0) {
   foreach ($delete_id as $id_d) {
     $sql = "DELETE FROM prisoner WHERE pri_id = '$id_d';";
     mysqli_query($conn,$sql);
   }
 }
 header("Location: ../prisoner.php?status=$id_d");
 exit();
}
else {
  header("Location: ../prisoner.php?status=notadmin");
}
}

// --------------------------------------------------------------------------------

if (isset($_POST['delete-fir'])) {
include_once 'dbh.inc.php';
if (  $_SESSION['admin'] == 1) {
 $delete_id =  $_POST['checkbox'];
 $id = count($delete_id);
 if (count($id) > 0) {
   foreach ($delete_id as $id_d) {
     $sql = "DELETE FROM fir WHERE fir_id = '$id_d';";
     mysqli_query($conn,$sql);
   }
 }
 header("Location: ../fir.php?status=$id_d");
 exit();
}
else {
  header("Location: ../fir.php?status=notadmin");
}
}
//--------------------------------------------------------------------------------


if (isset($_POST['delete-case'])) {
include_once 'dbh.inc.php';
if (  $_SESSION['admin'] == 1) {
 $delete_id =  $_POST['checkbox'];
 $id = count($delete_id);
 if (count($id) > 0) {
   foreach ($delete_id as $id_d) {
     $sql = "DELETE FROM cases WHERE case_id = '$id_d';";
     mysqli_query($conn,$sql);
   }
 }
 header("Location: ../cases.php?status=$id_d");
 exit();
}
else {
  header("Location: ../cases.php?status=notadmin");
}
}
// --------------------------------------------------------------------------------


if (isset($_POST['delete-courts'])) {
include_once 'dbh.inc.php';
if (  $_SESSION['admin'] == 1) {
 $delete_id =  $_POST['checkbox'];
 $id = count($delete_id);
 if (count($id) > 0) {
   foreach ($delete_id as $id_d) {
     $sql = "DELETE FROM court WHERE crt_id = '$id_d';";
     mysqli_query($conn,$sql);
   }
 }
 header("Location: ../courts.php?status=$id_d");
 exit();
}
else {
  header("Location: ../courts.php?status=notadmin");
}
}
// --------------------------------------------------------------------------------
if (isset($_POST['delete-victim'])) {
include_once 'dbh.inc.php';
if (  $_SESSION['admin'] == 1) {
 $delete_id =  $_POST['checkbox'];
 $id = count($delete_id);
 if (count($id) > 0) {
   foreach ($delete_id as $id_d) {
     $sql = "DELETE FROM victim WHERE vict_id = '$id_d';";
     mysqli_query($conn,$sql);
   }
 }
 header("Location: ../victim.php?status=$id_d");
 exit();
}

else {
  header("Location: ../victim.php?status=notadmin");
}
}
// --------------------------------------------------------------------------------
if (isset($_POST['delete-daily'])) {
include_once 'dbh.inc.php';
if (  $_SESSION['admin'] == 1) {
 $delete_id =  $_POST['checkbox'];
 $id = count($delete_id);
 if (count($id) > 0) {
   foreach ($delete_id as $id_d) {
     $sql = "DELETE FROM dailyreport WHERE did = '$id_d';";
     mysqli_query($conn,$sql);
   }
 }
 header("Location: ../dailyreport.php?status=$id_d");
 exit();
}

else {
  header("Location: ../dailyreport.php?status=notadmin");
}
}




 ?>
