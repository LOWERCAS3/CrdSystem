<?php
  include_once 'dbh.inc.php';
  if (isset($_POST['update-submit'])){
    $victId = $_GET['id'];
    $victimName = $_POST['vname'];
    $address = $_POST['addr'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $statement = $_POST['statement'];
    $sql = "UPDATE victim SET vict_name = '$victimName', vict_address = '$address', vict_age = '$age', vict_gender = '$gender', vict_statement = '$statement' WHERE vict_id = '$victId';";
    mysqli_query($conn,$sql);
    header("Location: ../victim.php?status=updated");
    exit();
}
if (isset($_POST['update-pri-submit'])){
  $priId = $_GET['id'];
  $name = $_POST['pname'];
  $addr = $_POST['address'] ;
  $age = $_POST['age'];
  $gender = $_POST['gender'];
  $arrest_date = $_POST['date'];
  $arrest_time = $_POST['time'];
  $crime = $_POST['crime'];
  $Description = $_POST['Description'];
  $status = $_POST['pstatus'];
  $sql = "UPDATE prisoner SET name='$name', address='$addr', age='$age', gender='$gender', arrest_date='$arrest_date', arrest_time='$arrest_time', crime='$crime',description='$Description'  ,sttus='$status' WHERE pri_id = '$priId';";
  mysqli_query($conn,$sql);
  header("Location: ../prisoner.php?status=updated");
  exit();
}



if (isset($_POST['update-fir-submit'])){
  $firId = $_GET['id'];
  $name = $_POST['Victim'];
  $region = $_POST['slct1'];
  $firdate = $_POST['FIR_Date'];
  $firtime = $_POST['Fir_Time'];
  $area = $_POST['slct2'];
  $suspects = $_POST['suspect'];
  $station = $_POST['station'];
  $description = $_POST['dscrptn'];
  // echo $suspects;
  $sql = "UPDATE fir SET victim='$name',fir_date='$firdate',fir_time='$firtime',dscrptn='$description',region='$region',area='$area',suspect='$suspects',station='$station' WHERE fir_id = '$firId';";
  mysqli_query($conn,$sql);
  header("Location: ../fir.php?status=updated");
  exit();
 }
?>
