<?php

if (isset($_POST['fir_submit']))
{
  include_once 'dbh.inc.php';
  $name = $_POST['Victim'];
  $region = $_POST['slct1'];
  $firdate = $_POST['FIR_Date'];
  $firtime = $_POST['Fir_Time'];
  $area = $_POST['slct2'];
  $suspects = $_POST['suspect'];
  $description = $_POST['dscrptn'];
  $station = $_POST['station'];

  $sql ="INSERT INTO fir (victim, fir_date, fir_time, dscrptn, region, area, suspect, station) VALUES ('$name' ,'$firdate','$firtime','$description','$region','$area','$suspects','$station');";
  mysqli_query($conn, $sql);
  header("Location: ../fir.php?status=entered");
  exit();
}
