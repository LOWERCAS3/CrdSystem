<?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';
 ?>
 <main>
<pre style="text-align: center;">
   <form class="" action="" method="POST">
     Enter time to get analysis :   time-from :  <input type="time" name="timefrom" value="">    time-to : <input type="time" name="timeto" value="">  <button type="submit" name="querybutton">submit</button>
  </form>
</pre>
<?php
 if (isset($_POST['querybutton'])) {
  $timefrom = $_POST['timefrom'];
  $timeto = $_POST['timeto'];

  $sql1 = "SELECT*FROM fir";
  $result1 = mysqli_query($conn,$sql1);
  $numrows1 = mysqli_num_rows($result1);
  // echo $numrows1;

  $sql2 = "SET @totalrows= '$numrows1';";
  mysqli_query($conn,$sql2);

  $sql = "SELECT * FROM fir WHERE fir_time BETWEEN '$timefrom' AND '$timeto'; ";
  $result = mysqli_query($conn,$sql);
  $numrows = mysqli_num_rows($result);

  $sql3 ="SET @searchedrows= '$numrows';";
  mysqli_query($conn,$sql3);

  $sql4 = "call percent(@totalrows,@searchedrows, @percentage);";
  mysqli_query($conn,$sql4);

  $sql5 = "SELECT @percentage;";
  $rslt =   mysqli_query($conn,$sql5);
  // echo $rslt ;
if ($numrows!='0') {
  while ($row1 = $rslt->fetch_assoc()) {?>
    <pre style="text-align: center;"> <?php echo  $row1['@percentage']."% of total FIRs had been lodged between ".$timefrom." and ".$timeto ;?></pre>

  <?php
 }


  // echo $numrows;
  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Fir Id</h1></td>
        <td><h1>Victim</h1></td>
        <td><h1>Fir Date</h1></td>
        <td><h1>Fir Time</h1></td>
        <td><h1>Description</h1></td>
        <td><h1>Region</h1></td>
        <td><h1>Area</h1></td>
        <td><h1>Suspect</h1></td>
          </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td> <a href='firsdetails.php?id={$row['fir_id']}'>{$row['fir_id']}</a></td>
          <td>{$row['victim']}</td>
          <td>{$row['fir_date']}</td>
          <td>{$row['fir_time']}</td>
          <td>{$row['dscrptn']}</td>
          <td>{$row['region']}</td>
          <td>{$row['area']}</td>
          <td>{$row['suspect']}</td>
          </tr>";
    }
  echo "</table>";
}
else {?>
<pre style="text-align: center;">
<?php   echo "No data found!"; ?>
</pre>
  <?php
}
}
?>
</main>
