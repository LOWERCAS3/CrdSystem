  <?php
  include_once 'includes/dbh.inc.php';
  include_once 'header.php';
  $priId = $_GET['id'];
  $sql = "SELECT * FROM prisoner WHERE  pri_id = '$priId'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_array($result);
  $priId = $row['pri_id'];
  $name = $row['name'];
  $addr = $row['address'];
  $age = $row['age'];
  $gender = $row['gender'];
  $arrest_date = $row['arrest_date'];
  $arrest_time = $row['arrest_time'];
  $crime = $row['crime'];
  $Description = $row['description'];
  $status = $row['sttus'];
  $image = $row['image'];
  ?>
  <main class="pridetails">
    <link rel="stylesheet" href="style.css">
  <fieldset class="priedit">
  <h1 class="toptitle">DEFENDENT DETAILS</h1><br>
  <hr>
  <br>
  <form class="priform" action="includes/update.inc.php?id=<?php echo $priId;  ?>" method="post">
  <p>Defendent ID&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;<?php echo $priId;  ?></p><br>
  <p>Name&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;<input autocomplete=" off" type="text" name="pname" value="<?php echo $name; ?>"></p><br>
  <span class=" priImg"> <?php echo '<img src="data:image/jpg;base64,'.base64_encode($row['image']).'"width="250" height="250" >';?></span>
  <p>Arrest Date&emsp;:&emsp;&emsp;&emsp;&emsp;<input autocomplete=" off" type="text" name="date" placeholder="YYYY-MM-DD" value="<?php echo $arrest_date; ?>"></p><br>
  <p>Arrest Time&emsp;:&emsp;&emsp;&emsp;&emsp;<input autocomplete=" off" type="text" name="time" placeholder="In 24hr Format (HH:MM)" value="<?php echo $arrest_time; ?>"></p><br>
  <p>Crime&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;<select  required style="color: black;" name="crime">
                          <option value="<?php echo $crime; ?>"><?php echo $crime; ?></option>
                          <option value="Antisocial&nbsp;behaviour">Antisocial behaviour</option>
                          <option value="Arson">Arson</option>
                          <option value="Burglary">Burglary</option>
                          <option value="Childhood abuse">Childhood abuse</option>
                          <option value="Crime abroad">Crime abroad</option>
                          <option value="Cyber crime">Cyber crime</option>
                          <option value="Domestic abuse">Domestic abuse</option>
                          <option value="Fraud">Fraud</option>
                          <option value="Hate crime">Hate crime</option>
                          <option value="Murder">Murder</option>
                          <option value="Rape and sexual assault">Rape and sexual assault</option>
                          <option value="Revenge porn">Revenge porn</option>
                          <option value="Robbery">Robbery</option>
                          <option value="Sexual harassment">Sexual harassment</option>
                          <option value="Stalking and harassment">Stalking and harassment</option>
                          <option value="Terrorism">Terrorism</option>
                          <option value="Violent crime">Violent crime</option>
                      </select><br></p><br><br>
  <p>Description&emsp;:&emsp;&emsp;&emsp;&emsp;&nbsp;<textarea name="Description" rows="4" cols="50"><?php echo $Description; ?></textarea></p><br>
  <p>Gender&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Male&emsp;:&emsp;<input required type="radio" name="gender" value="Male"> &emsp; Female&emsp;:&emsp;<input type="radio" name="gender" value="Female"></p><br>
  <p>Age&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<input autocomplete=" off" type="text" name="age" value="<?php echo $age; ?>"></p><br>
  <p>Status&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<select required style="color: black;" name="pstatus">
   <option value="<?php echo $status; ?>"><?php echo $status; ?></option>
   <option value="Arrested">Arrested</option>
   <option value="On Bail">On Bail</option>
   <option value="Sentenced">Sentenced</option></select></p><br><br>
  <p>Address&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;<textarea name="address" rows="4" cols="50"><?php echo $addr; ?></textarea></p><br>
  <button class="update-pri-submit" type="submit" name="update-pri-submit">Update</button>
  </form>
  </fieldset>

  </main>
