<?php
 if (!isset($_POST['querynbutton'])) {
  $datefrom = $_POST['datefrom'];
  $dateto = $_POST['dateto'];
  $sql = "SELECT * FROM fir WHERE fir_date BETWEEN '$datefrom' AND '$dateto' ";
  $result = mysqli_query($conn,$sql);
  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Fir Id</h1></td>
        <td><h1>Victim</h1></td>
        <td><h1>Fir Date</h1></td>
        <td><h1>Fir Time</h1></td>
        <td><h1>Description</h1></td>
        <td><h1>Region</h1></td>
        <td><h1>Area</h1></td>
        <td><h1>Suspect</h1></td>
        <td><h1>Delete</h1></td>
        </tr>";

  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td> <a href='firsdetails.php?id={$row['fir_id']}'>{$row['fir_id']}</a></td>
          <td>{$row['victim']}</td>
          <td>{$row['fir_date']}</td>
          <td>{$row['fir_time']}</td>
          <td>{$row['dscrptn']}</td>
          <td>{$row['region']}</td>
          <td>{$row['area']}</td>
          <td>{$row['suspect']}</td>
          <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['fir_id']}' /></td>
          <td><a href='firedit.php?id={$row['fir_id']}'>Edit</a></td>
          </tr>";
    }
  echo "</table>";
}
?>
