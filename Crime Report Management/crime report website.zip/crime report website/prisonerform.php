<?php
include_once 'header.php';
  ?>
<main>
    <form class="" action="includes/prisoner.inc.php" method="post" enctype="multipart/form-data">
        <h1 class="formtitle">NEW DEFENDANT DETAILS</h1>
      <hr>
      <pre>

            Upload Image:     <input style="color: white;" type="file" required name="image">

            Name:                     <input required type="text" name="pname" value=""><br>
            Address:                 <textarea required name="addr" rows="3" cols="90"></textarea><br>
            Age:                         <input required  type="text" name="age" value=""><br>
            Gender:                  Male: <input required type="radio" name="gender" value="Male">       Female: <input type="radio" name="gender" value="Female"> <br>
            Arrest Date:           <input required type="date" style="color: black;" name="date" placeholder="YYYY-MM-DD"><br>
            Arrest Time:           <input required type="time" style="color: black;" name="time"><br>
            Crime:                       <select  required style="color: black;" name="crime">
                                    <option value="">Select</option>
                                    <option value="Antisocial&nbsp;behaviour">Antisocial behaviour</option>
                                    <option value="Arson">Arson</option>
                                    <option value="Burglary">Burglary</option>
                                  <option value="Childhood abuse">Childhood abuse</option>
                                  <option value="Crime abroad">Crime abroad</option>
                                  <option value="Cyber crime">Cyber crime</option>
                                  <option value="Domestic abuse">Domestic abuse</option>
                                  <option value="Fraud">Fraud</option>
                                  <option value="Hate crime">Hate crime</option>
                                  <option value="Murder">Murder</option>
                                  <option value="Rape and sexual assault">Rape and sexual assault</option>
                                  <option value="Revenge porn">Revenge porn</option>
                                  <option value="Robbery">Robbery</option>
                                  <option value="Sexual harassment">Sexual harassment</option>
                                  <option value="Stalking and harassment">Stalking and harassment</option>
                                  <option value="Terrorism">Terrorism</option>
                                  <option value="Violent crime">Violent crime</option>
                                  </select><br>

            Description:                    <textarea style=" color: black;" name="Description" rows="3" cols="90"></textarea><br>
            Status:                   <select  style="color: black;" name="pstatus">
                                    <option value="">Select</option>
                                    <option value="Not yet arrested">Not yet arrested</option>
                                    <option value="Arrested">Arrested</option>
                                    <option value="On Bail">On Bail</option>
                                    <option value="Sentenced">Sentenced</option></select><br>
        </pre>
        <button class="prisonerformbutton" type="submit" name="prisoner_submit">Submit</button>
    </form>
</main>

<?php
  if(!empty($_GET)){
    if($_GET['status']=='format'){
      echo '<script> alert("Unsupported image format!"); </script>';
    }
  }
?>
