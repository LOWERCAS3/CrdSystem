<?php include_once 'header.php';?>
<main>
  <script>
    function populate(s1,s2){
      var s1 = document.getElementById(s1);
      var s2 = document.getElementById(s2);
      s2.innerHTML = "";
      s2.value = "Select";
      if(s1.value == "Bastar"){
        var optionArray = ["|Select","Bastar|Bastar","Bijapur|Bijapur","Dantewada|Dantewada","Kondagaon|Kondagaon","Narayanpur|Narayanpur","Kanker|Kanker"];
      } else if(s1.value == "Bilaspur"){
        var optionArray = ["|Select","Bilaspur|Bilaspur"," Mungeli|Mungeli ","Korba|Korba","Janjgir Champa|Janjgir Champa","Raigarh|Raigarh"];
      } else if(s1.value == "Durg"){
        var optionArray = ["|Select","Kawardha|Kawardha","Rajnandgaon|Rajnandgaon","Balod|Balod","Durg|Durg","Bemetara|Bemetara"];
      } else if(s1.value == "Raipur"){
        var optionArray = ["|Select","Dhamtari|Dhamtari","Gariyaband|Gariyaband","Raipur|Raipur","Baloda Bazar|Baloda Bazar","Mahasamund|Mahasamund"];
      } else if(s1.value == "Surguja"){
        var optionArray = ["|Select","Koriya|Koriya","Surajpur|Surajpur","Balrampur Ramanujgang|Balrampur Ramanujgang"," Jashpur|Jashpur "];
      }

      for(var option in optionArray){
        var pair = optionArray[option].split("|");
        var newOption = document.createElement("option");
        newOption.value = pair[0];
        newOption.innerHTML = pair[1];
        s2.options.add(newOption);
      }
    }
        function populate1(s1,s2){
      var s1 = document.getElementById(s1);
      var s2 = document.getElementById(s2);
      s2.innerHTML = "";
      s2.value = "Select";
      if(s1.value == "Bastar"){
        var optionArray = ["|Select","Bodhghat|Bodhghat","Parpa|Parpa","Bhanpuri|Bhanpuri"];
      } else if(s1.value == "Bilaspur"){
        var optionArray = ["|Select","Civil Lines|Civil Lines"," City Kotwali|City Kotwali ","Sarkanda|Sarkanda"];
      } else if(s1.value == "Durg"){
        var optionArray = ["|Select","Mohan Nagar|Mohan Nagar","Pulgaon|Pulgaon","Bhilai Nagar|Bhilai Nagar"];
      } else if(s1.value == "Raipur"){
        var optionArray = ["|Select","Civil Lines|Civil Lines","Telibanda|Telibanda","Gudiyari|Gudiyari"];
      } else if(s1.value == "Koriya"){
        var optionArray = ["|Select","Kotwali|Kotwali","Gandhi Nagar|Gandhi Nagar"," Cyber Cell|Cyber Cell"];
      }

      for(var option in optionArray){
        var pair = optionArray[option].split("|");
        var newOption = document.createElement("option");
        newOption.value = pair[0];
        newOption.innerHTML = pair[1];
        s2.options.add(newOption);
      }
    }
  </script>
  <h1 class="formtitle">LODGE FIR</h1>
  <hr>
  <form class="" action="includes/fir.inc.php" method="post">
    <pre>

                Name  :                    <input type="text" required name="Victim" ><br>
                FIR Date  :                 <input type="date" required name="FIR_Date"><br>
                FIR Time  :                 <input type="time" required name="Fir_Time" ><br>
                Region  :                   <select style="color: black;" id="slct1" required name="slct1" onchange="populate(this.id,'slct2')">
                                                <option value="">Select</option>
                                                <option value="Bastar">Bastar</option>
                                                <option value="Bilaspur">Bilaspur</option>
                                                <option value="Drug">Drug</option>
                                                <option value="Raipur">Raipur</option>
                                                <option value="Surguja">Surguja</option></select><br><br>
                Area    :                       <select style="color: black;" id="slct2" required name="slct2" onchange="populate1(this.id,'slct3')"></select><br>
                Station Name  :       <input type="text" required name="station"  ><br>
                Suspects  :                 <input type="text" name="suspect" ><br>
                Description :             <textarea  type="text" rows="3" cols="90" required name="dscrptn" placeholder="Fill here.."  ></textarea><br><br>
    </pre>
      <button  class="prisonerformbutton" type="submit" name="fir_submit">Submit</button>
    </form>
  </main>
