<link rel="stylesheet" href="style.css">
 <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
<main class="headerPHP">
  <div class="headerlogo">
    <ul>
    <a href="index.php"><img  class="nav-header-logo" src="img/icon.png" alt="logo" ></a>

    <li><a href="index.php">Home</a></li>
    <li><a href="gallery.php">Gallery</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="contact.php">Contact</a></li>
          </ul>
    <?php
      if (isset($_SESSION['userId'])) {
        echo   '  <form class="" action="includes/logout.inc.php" method="post">
                  <button type="submit" name="logout-submit">Logout</button>
                  </form>';
      }
    ?>
  </div>
    <hr style="margin-top: 65px;">
  <main style="margin-top: 150px;">
    <p>Bangalore: The Karnataka State Police now has a toll free number. A toll-free number — 1800-425-0100 — has been commissioned at the DGP Control Room, Police Headquarters, Nrupathunga Road.</p><br>

<p>According to a press release here on Tuesday, R. Sri Kumar, Director-General and Inspector-General of Police, will formally inaugurate the facility on Thursday. It is said that he will personally receive calls between 10.05 a.m. and 11.05 a.m.</p><br>

<p>The calls made to this number from anywhere in India are free of cost and the callers’ identity will be kept confidential. People may contact the toll free number round-the-clock to seek police assistance. The operators of the DGP Control Room will receive these calls and convey the information to senior police officials.</p><br>

<p>The release added that at pre-determined dates and time, during working days, the calls will be received personally by senior police officials, including Mr. Srikumar and Additional Directors-General of Police for necessary action to redress the public’s grievances. The programme of senior officials receiving calls on the toll-free number will be available on Karnataka State Police website ( >www.ksp.gov.in).</p><br>
  </main>
