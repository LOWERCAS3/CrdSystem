<?php include_once 'header.php';
?>
<main>
  <h1 class="formtitle">NEW CASE</h1>
<hr>
<pre>

  <form class="" action="includes/cases.inc.php" method="post"><br>
                Fir Id  :                     <input type="text" name="fir_id" value=""><br>
                Defendent Id :          <input type="text" name="pri_id" ><br>
                Court Id  :              <input type="text" name="crt_id" value=""><br>
                Hearing Date  :    <input type="date" name="hearing_date"><br>
                Arrests :                 <input type="" name="arrests" value=""><br>
    <button class="prisonerformbutton" type="submit" name="cases_submit">Submit</button>
  </form>
</pre>
</main>
