<?php
include_once 'includes/dbh.inc.php';
include_once 'header.php';
 ?>
 <main>
   <pre style="text-align: center;">
<form class="" action="" method="post">
  Enter dates to get analysis :   date-from :  <input required type="date" name="datefrom" value="">    date-to : <input required type="date" name="dateto" value="">  <button type="submit" name="querybutton">submit</button>
</form>
</pre>

<?php
 if (isset($_POST['querybutton'])) {
   $datefrom = $_POST['datefrom'];
   $dateto = $_POST['dateto'];

  $sql1 = "SELECT*FROM prisoner";
  $result1 = mysqli_query($conn,$sql1);
  $numrows1 = mysqli_num_rows($result1);
  // echo $numrows1;

  $sql2 = "SET @totalrows= '$numrows1';";
  mysqli_query($conn,$sql2);

  $sql = "SELECT * FROM prisoner WHERE arrest_date BETWEEN '$datefrom' AND '$dateto';";
  $result = mysqli_query($conn,$sql);
  $numrows = mysqli_num_rows($result);
  // echo $numrows;

  $sql3 ="SET @searchedrows= '$numrows';";
  mysqli_query($conn,$sql3);

  $sql4 = "call percent(@totalrows,@searchedrows, @percentage);";
  mysqli_query($conn,$sql4);

  $sql5 = "SELECT @percentage;";
  $rslt =   mysqli_query($conn,$sql5);
  // echo $rslt ;

  echo "<table class='showtable' border='1'>";
  echo " <tr><td><h1>Defendants Id</h1></td>
            <td><h1>Name</h1></td>
            <td><h1>Address</h1></td>
            <td><h1>Age</h1></td>
            <td><h1>Gender</h1></td>
            <td><h1>Arrest Date</h1></td>
            <td><h1>Arrest Time</h1></td>
            <td><h1>Crime</h1></td>
            <td><h1>Status</h1></td>
            </tr>";

while ($row = mysqli_fetch_assoc($result)) {
echo "<tr><td> <a href='prisonersdetails.php?id={$row['pri_id']}'>{$row['pri_id']}</a></td>
          <td>{$row['name']}</td>
          <td>{$row['address']}</td>
          <td>{$row['age']}</td>
          <td>{$row['gender']}</td>
          <td>{$row['arrest_date']}</td>
          <td>{$row['arrest_time']}</td>
          <td>{$row['crime']}</td>
          <td>{$row['sttus']}</td>
          </tr>";
        }
echo "</table>";

while ($row1 = $rslt->fetch_assoc()) {?>
  <pre style="text-align: center;"><?php echo  $row1['@percentage']."% of defendants are arrested between ".$datefrom." and ".$dateto."."; ?></pre>
<?php
}
}
?>
</main>
