  <?php
    session_start();
  ?>

  <link rel="stylesheet" href="style.css">
   <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
  <main class="headerPHP">
    <div class="headerlogo">
      <ul>
      <a href="index.php"><img  class="nav-header-logo" src="img/icon.png" alt="logo" ></a>

      <li><a href="index.php">Home</a></li>
      <li><a href="gallery.php">Gallery</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="contact.php">Contact</a></li>
            </ul>
      <?php
        if (isset($_SESSION['userId'])) {
          echo   '  <form class="" action="includes/logout.inc.php" method="post">
                    <button type="submit" name="logout-submit">Logout</button>
                    </form>';
        }
      ?>
    </div>
    <hr style="margin-top: 65px;">
    <ul style="margin-top: 150px;" class="dashboard">
          <li class="d1"><button style="min-width: 340px; min-height: 200px; border: 1px solid; border-radius: 15px;" type="submit" onclick="location.href='fir.php'" name="">Go to Databases</button></li>
          <li class="d2"><button style="min-width: 340px; min-height: 200px; border: 1px solid; border-radius: 15px;" type="submit" onclick="location.href='casesform.php'" name="">File a Case</button></li>
          <li class="d3"><button style="min-width: 340px; min-height: 200px; border: 1px solid; border-radius: 15px;" type="submit" onclick="location.href='prisonerform.php'" name="">Add Defendent Info</button></li>
          <li class="d4"><button style="min-width: 340px; min-height: 200px; border: 1px solid; border-radius: 15px;" type="submit" onclick="location.href='firform.php'" name="">Report an FIR</button></li>
          <li class="d5"><button style="min-width: 340px; min-height: 200px; border: 1px solid; border-radius: 15px;" type="submit" onclick="location.href='query.php'" name="">Queries</button></li>
</ul>

</main>
