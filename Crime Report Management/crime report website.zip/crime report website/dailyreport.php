<?php
include_once 'header.php';
include_once 'includes/dbh.inc.php';
$sql = "SELECT * FROM dailyreport";
$result = mysqli_query($conn, $sql) or die("Bad query: $sql");
?>
<main>
  <p style="font-size: 30px; text-align: center;">Daily Report</p>
  <form  class="searchbox" action="dailyreport.php" method="post">
    <input type="text" name="search">
    <button type="submit" name="viewbutton">Search</button>
  </form>
  <button class="info" type="submit" onclick="location.href='dailyform.php'">File a Report</button>
  <form class="" action="includes/delete.inc.php" method="post">
  <button class="del" type="submit"name="delete-daily">Delete</button>
    <?php
    if (!isset($_POST['viewbutton'])) {
    echo "<table class='showtable' border='1'>";
    echo " <tr><td><h1>Report Id</h1></td>
              <td><h1>Name</h1></td>
              <td><h1>Age</h1></td>
              <td><h1>Gender</h1></td>
              <td><h1>Report Date</h1></td>
              <td><h1>Reason</h1></td>
              <td><h1>Description</h1></td>
              <td><h1>Address</h1></td>
              <td><h1>Delete</h1></td>
              </tr>";
    while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>{$row['did']}</td>
          <td>{$row['dname']}</td>
          <td>{$row['dage']}</td>
          <td>{$row['dgender']}</td>
          <td>{$row['ddate']}</td>
          <td>{$row['dreason']}</td>
          <td>{$row['ddescription']}</td>
          <td>{$row['daddress']}</td>
          <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['did']}' /></td>
          <tr>";
        }
    echo "</table>";
  }
    else {
      $search = $_POST['search'];
      $sql = "SELECT * FROM dailyreport WHERE did LIKE '%$search%' OR  dname LIKE '%$search%';";
      $result = mysqli_query($conn,$sql);
      echo "<table class='showtable' border='1'>";
      echo " <tr><td><h1>Report Id</h1></td>
                <td><h1>Name</h1></td>
                <td><h1>Age</h1></td>
                <td><h1>Gender</h1></td>
                <td><h1>Report Date</h1></td>
                <td><h1>Reason</h1></td>
                <td><h1>Description</h1></td>
                <td><h1>Address</h1></td>
                <td><h1>Delete</h1></td>
                </tr>";
    while ($row = mysqli_fetch_assoc($result)) {
      echo "<tr><td>{$row['did']}</td>
            <td>{$row['dname']}</td>
            <td>{$row['dage']}</td>
            <td>{$row['dgender']}</td>
            <td>{$row['ddate']}</td>
            <td>{$row['dreason']}</td>
            <td>{$row['ddescription']}</td>
            <td>{$row['daddress']}</td>
            <td><input name='checkbox[]' type='checkbox' id='checkbox[]' value='{$row['did']}' /></td>
            <tr>";
          }
      echo"</table>";
    }
?>
</form>
</main>
<?php

if (!empty($_GET)) {
if ($_GET['status']== "notadmin") {
echo "<script>
alert('You do not have necessary privileges.');
</script>";
}
}

?>
